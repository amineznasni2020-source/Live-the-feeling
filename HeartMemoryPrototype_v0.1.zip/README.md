# HeartMemory Prototype v0.1

Zero-budget Android MVP for the concept:
- Memory gallery
- Create a memory
- Photo selection entry point
- Heart rate + mood
- Memory playback screen

Next iterations:
1. Persist memories locally.
2. Display selected photo.
3. Connect supported smartwatch data through Health Connect / wearable APIs.
4. Add on-device or free-tier AI for image/mood analysis.
5. Generate adaptive visual/audio playback.
