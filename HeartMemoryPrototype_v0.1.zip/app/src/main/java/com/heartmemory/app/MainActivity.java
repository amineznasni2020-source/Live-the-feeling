package com.heartmemory.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, gallery;
    ArrayList<Memory> memories = new ArrayList<>();
    int purple = Color.rgb(124,77,255), dark = Color.rgb(11,11,18);

    public void onCreate(Bundle b){
        super.onCreate(b);
        showGallery();
    }

    TextView tv(String s, float size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setPadding(24,18,24,18); return t;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); return b;
    }

    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(dark);
        TextView h=tv(title,26); h.setTypeface(null,1); root.addView(h);
        setContentView(root);
    }

    void showGallery(){
        base("♥ HeartMemory");
        TextView sub=tv("Your memories, with the feeling inside them.",15);
        root.addView(sub);
        Button add=btn("+  Create a Memory"); add.setOnClickListener(v->createMemory());
        root.addView(add);
        gallery=new LinearLayout(this); gallery.setOrientation(LinearLayout.VERTICAL);
        root.addView(gallery,new LinearLayout.LayoutParams(-1,0,1));
        if(memories.isEmpty()) gallery.addView(tv("No memories yet.\nTake your first emotional snapshot.",17));
        for(Memory m: memories){
            Button x=btn("♥  "+m.title+"   •  "+m.hr+" BPM   •  "+m.mood);
            x.setOnClickListener(v->playMemory(m)); gallery.addView(x);
        }
    }

    void createMemory(){
        base("Create a Memory");
        root.addView(tv("Prototype mode: heart rate can be entered manually until smartwatch integration is added.",14));
        EditText title=new EditText(this); title.setHint("Memory name"); root.addView(title);
        EditText hr=new EditText(this); hr.setHint("Heart rate (BPM)"); hr.setInputType(2); root.addView(hr);
        Spinner mood=new Spinner(this);
        String[] moods={"Calm","Happy","Excited","Emotional","Sad","Love","Surprised"};
        mood.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,moods));
        root.addView(mood);
        Button photo=btn("📷  Choose a photo"); root.addView(photo);
        TextView selected=tv("No photo selected",14); root.addView(selected);
        final Uri[] uri={null};
        photo.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,10);});
        Button save=btn("Save Memory"); root.addView(save);
        save.setOnClickListener(v->{
            String n=title.getText().toString().trim(); if(n.isEmpty()) n="My Memory";
            int h=70; try{h=Integer.parseInt(hr.getText().toString());}catch(Exception e){}
            memories.add(new Memory(n,h,mood.getSelectedItem().toString(),uri[0]));
            showGallery();
        });
    }

    protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==10 && c==RESULT_OK && d!=null){
            Uri u=d.getData();
            if(u!=null) { try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception e){} }
            // kept simple for prototype; image URI is stored when save is implemented in next iteration
        }
    }

    void playMemory(Memory m){
        base("Re-live: "+m.title);
        TextView pulse=tv("♥  "+m.hr+" BPM",32); pulse.setGravity(Gravity.CENTER); root.addView(pulse);
        TextView mood=tv("AI mood: "+m.mood+"\n\nThe prototype is simulating the memory atmosphere.\nIn the full version, AI will analyze facial expression and generate a visual + adaptive soundtrack.",18);
        mood.setGravity(Gravity.CENTER); root.addView(mood,new LinearLayout.LayoutParams(-1,0,1));
        Button back=btn("← Back to Gallery"); back.setOnClickListener(v->showGallery()); root.addView(back);
    }

    static class Memory {
        String title,mood; int hr; Uri photo;
        Memory(String t,int h,String m,Uri p){title=t;hr=h;mood=m;photo=p;}
    }
}
